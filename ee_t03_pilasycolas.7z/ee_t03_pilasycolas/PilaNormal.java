import javax.swing.*;

public class PilaNormal<T> {
	
	public ListaLigada<T> pila = new ListaLigada<T>();
    
               public void push(T dato){
        pila.agregarFinal(dato);
    }
    
    public T pop(){
        return pila.eliminaFinalDevolv();
    }
    
   public T peek(){
               //ee_t03_pilasycolas.Nodo<T> tempo = pila.getInicio();
               Nodo<T> tempo = pila.getInicio();
        if(tempo == null)
           return null;
           
  try{
      
            while(tempo.getSiguiente() != null)
                  tempo = tempo.getSiguiente();
        }
  catch(NullPointerException e){
            JOptionPane.showMessageDialog(null,"Lista vacÃ­a");
            
        }
        return tempo.getDato();
    }
    
    public Boolean isVacia(){
        return pila.getInicio() == null;
    }
}
