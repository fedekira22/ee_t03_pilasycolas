public class ColaNormal<T> {
	
	private ListaLigada<T> cola = new ListaLigada<T>();
    
    public void insertar(T dato){
        cola.agregarFinal(dato);
    }
    
    public T retirar(){
        return cola.eliminaInicioDevolviendo();
    }
}